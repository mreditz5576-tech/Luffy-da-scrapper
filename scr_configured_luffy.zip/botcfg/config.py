"""
LUFFY Scraper Bot - Configuration
Version: 3.0.0
"""

import os
import logging
from typing import List
from pathlib import Path

# ============ Path Configuration ============
BASE_DIR = Path(__file__).parent
TEMP_DIR = BASE_DIR / "temp"
LOG_DIR = BASE_DIR / "logs"

# Create directories
for directory in [TEMP_DIR, LOG_DIR]:
    directory.mkdir(exist_ok=True, parents=True)

# ============ Telegram Configuration ============
API_ID: int = 35742794
API_HASH: str = "8079bf30d2dc4f9558a5fd0f3fdb5ca1"
SESSION_STRING: str = "BQIhZEoAi3dOWwTWpEft0sPA20rziLAYYvvV3ZOHMi0tlE9QSmj86603e_gOSkiZe7FHOGX6AjzBpMtywcAEO4_VTFdZDejLA6Ps-l-hp9TD6KKekReh4fc6khWagMfpof_--Mh8_wnXl1eAcoHi-B6_8MN13tjLPA_GJoKGq7dzc3sLq_sqwT8YNsX0Gc6P_ARfgghgEuf7VmQh4WAfJqyB7BazHPqF70jxzsVyIGwNBIOzVo-4j0mSfeAH0VOtPFgdxH3QQOindYqjBDL4V91dHHUDxUATe1Z2A2n8IpujIkp3SUUxmsUZcN30u8kCECUW69OIdyoTxkQ724BVRPeC0tsVlwAAAAIX8YiGAA"

# Keep the bot token out of source files; set TELEGRAM_BOT_TOKEN in the runtime environment.
BOT_TOKEN: str = os.environ.get("TELEGRAM_BOT_TOKEN", "")
if not BOT_TOKEN:
    raise RuntimeError("Set TELEGRAM_BOT_TOKEN in the environment before starting the bot.")

# ============ Admin Configuration ============
ADMIN_IDS: List[int] = [8220997953]

# ============ Limits Configuration ============
DEFAULT_LIMIT: int = 5000
ADMIN_LIMIT: int = 100000
SEARCH_LIMIT: int = 10000

# ============ Bot Information ============
BOT_OWNER: str = "LUFFY_BR0"
BOT_CHANNEL: str = "Xabout_luffy"

# ============ Performance Configuration ============
WORKERS: int = 1000
MAX_CONCURRENT_TASKS: int = 10

# ============ Logging Configuration ============
LOG_LEVEL: str = "INFO"
LOG_FILE: Path = LOG_DIR / "bot.log"

print("=" * 50)
print("📋 LUFFY BOT CONFIGURATION")
print("=" * 50)
print(f"🔑 Bot Token: {BOT_TOKEN[:15]}...{BOT_TOKEN[-5:]}")
print(f"📏 Token Length: {len(BOT_TOKEN)}")
print(f"👥 Admins: {ADMIN_IDS}")
print(f"📊 Default Limit: {DEFAULT_LIMIT}")
print(f"⭐ Admin Limit: {ADMIN_LIMIT}")
print("=" * 50)