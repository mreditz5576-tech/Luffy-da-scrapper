# user_manager.py
import json
from pathlib import Path
from typing import List, Dict

class UserDataManager:
    def __init__(self, data_file: str = "user_data.json"):
        self.data_file = Path(data_file)
        self.data: Dict = {}
        self.load_data()
    
    def load_data(self) -> None:
        if self.data_file.exists():
            try:
                with open(self.data_file, 'r') as f:
                    self.data = json.load(f)
            except:
                self.data = {}
    
    def save_data(self) -> None:
        with open(self.data_file, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def get_user_channels(self, user_id: int) -> List[str]:
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {"channels": []}
        return self.data[user_id].get("channels", [])
    
    def add_user_channel(self, user_id: int, channel: str) -> None:
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {"channels": []}
        if channel not in self.data[user_id]["channels"]:
            self.data[user_id]["channels"].append(channel)
            self.save_data()
    
    def remove_user_channel(self, user_id: int, channel: str) -> None:
        user_id = str(user_id)
        if user_id in self.data:
            if channel in self.data[user_id]["channels"]:
                self.data[user_id]["channels"].remove(channel)
                self.save_data()