"""
LUFFY Scraper Bot - Professional Version
Author: LUFFY_BR0
Version: 3.0.7 - Fixed for Aiogram 3.10.0
"""

import asyncio
import os
import sys
import re
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union

# ============ Fix Event Loop for Python 3.10+ ============
try:
    asyncio.get_running_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

# ============ Third Party Imports ============
from pyrogram import Client as PyroClient
from pyrogram.errors import (
    UserAlreadyParticipant,
    InviteHashExpired,
    InviteHashInvalid,
    PeerIdInvalid,
    InviteRequestSent,
    FloodWait,
)
from pyrogram.types import Chat
from pyrogram.enums import ChatType, ChatMemberStatus

from aiogram import Bot, Dispatcher, types, F
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
    CallbackQuery,
    Message,
    User
)
from aiogram.filters import Command, CommandObject
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties  # ✅ REQUIRED FOR 3.7+
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramNetworkError,
    TelegramRetryAfter
)

import aiofiles
from config import (
    API_ID,
    API_HASH,
    BOT_TOKEN,
    SESSION_STRING,
    ADMIN_LIMIT,
    ADMIN_IDS,
    DEFAULT_LIMIT,
    BOT_OWNER,
    BOT_CHANNEL,
    LOG_LEVEL,
    LOG_FILE,
    WORKERS,
    TEMP_DIR,
    LOG_DIR,
)
from user_manager import UserDataManager

# ============ Initialize Managers ============
user_manager = UserDataManager()

# ============ Logging Setup ============
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Suppress noisy loggers
logging.getLogger("pyrogram").setLevel(logging.WARNING)
logging.getLogger("aiogram").setLevel(logging.WARNING)
logging.getLogger("aiohttp").setLevel(logging.WARNING)

# ============ Premium Emoji IDs ============
PREMIUM_EMOJI_IDS = {
    "✅": "5444987348334965906", "❌": "5447647474984449520",
    "🔥": "5116414868357907335", "⚡": "5219943216781995020",
    "💳": "5447453226498552490", "💠": "4904936030232117798",
    "📝": "6266764202950530136", "📊": "5445146408153806223",
    "⏳": "5258113901106580375", "🚀": "5343887395894882351",
    "⚠️": "4915853119839011973", "💎": "5343636681473935403",
    "👋": "5134476056241112076", "💡": "5301275719681190738",
    "📈": "5134457377428341766", "🔢": "5444931419270839381",
    "🔌": "5120722716260828125", "⭐️": "5172716095697584957",
    "🆓": "5406756500108501710", "👑": "6266995104687330978",
    "🔍": "5258396243666681152", "⏱️": "5343927661213279013",
    "💥": "5122933683820430249", "🆔": "5447311106030726740",
    "👤": "5445174334031166029", "📅": "5343927661213279013",
    "🔄": "5454245266305604993", "🏦": "5445408306669582934",
    "🥰": "5444931419270839381", "😱": "5447181973544008180",
    "🔷": "5301275719681190738", "🔑": "5454386656628991407",
    "📆": "5343927661213279013", "👥": "5454371323595744068",
    "🥕": "5447653032672129347", "➡️": "5445350109862720603",
    "🦉": "5123344136665039833", "🍑": "5445408306669582934",
    "💪": "5305622454218024328", "🌝": "5341684837881235158",
    "📁": "5444908424015934570", "ℹ️": "5289930378885214069",
    "💀": "5231338559587257737", "📢": "5116445341150872576",
    "💰": "5116648080787112958", "🔘": "5219901967916084166",
    "🔗": "5447479640547428304", "👇": "5122933683820430249",
    "📌": "5447187153274567373", "🍳": "5305622454218024328",
    "💸": "5283232570660634549", "🎉": "5172632227871196306",
    "🎁": "5283031441637148958", "🚫": "5116151848855667552",
    "🛒": "5447319442562251569", "🔧": "4904936030232117798",
    "⛔️": "5275969776668134187", "🥲": "4904468402782864209",
    "☠️": "5231338559587257737", "🛡": "5219672809936006424",
    "📸": "5445344161333015312", "💬": "5447510826304959724",
    "😺": "5118590136149345664", "🌍": "5303440357428586778",
    "🔹": "5301275719681190738", "📹": "5445158077579952110",
    "📡": "5447448489149625830", "🌟": "5310224206732996002",
    "📍": "5447187153274567373", "🔐": "5258476306152038031",
    "😇": "6321225560789877992", "👌": "5445350109862720603",
    "⭐": "6267298050205553492", "🍭": "6267152480878990865",
    "⚙️": "5258023599419171861", "⛔": "4918014360267260850",
    "📥": "5350747347724810871", "💵": "5350711759625795085",
    "📂": "5444908424015934570", "🛠️": "5348239232852836489",
    "📎": "5282531402821991529", "🖥️": "5258574977633567931",
    "⌨️": "5258334330740171131", "🛡️": "5219672809936006424",
    "🔒": "5258476306152038031", "🔓": "5258476306152038031",
    "📤": "5350747347724810871", "🕒": "5258113901106580375",
}

def premium_emoji(text: str) -> str:
    """Replace emojis with premium Telegram emojis"""
    if not text:
        return text
    result = text
    for emoji, emoji_id in PREMIUM_EMOJI_IDS.items():
        result = result.replace(emoji, f'<tg-emoji emoji-id="{emoji_id}">{emoji}</tg-emoji>')
    return result

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe filesystem usage"""
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    filename = ''.join(char for char in filename if char.isprintable())
    return filename[:200]

def format_duration(seconds: float) -> str:
    """Format duration in seconds to readable format"""
    if seconds < 60:
        return f"{seconds:.0f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"

def create_progress_bar(percentage: float, width: int = 15) -> str:
    """Create a progress bar"""
    filled = int((percentage / 100) * width)
    empty = width - filled
    return f"[{'█' * filled}{'░' * empty}]"

# ============ Initialize Clients ============

# Pyrogram Client
user = PyroClient(
    "user_session",
    session_string=SESSION_STRING,
    workers=WORKERS,
    sleep_threshold=60,
    parse_mode=None
)

# ✅ FIXED - Aiogram 3.7.0+ compatible with DefaultBotProperties
logger.info(f"🔑 Initializing bot with token: {BOT_TOKEN[:15]}...")
bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

# ============ Messages ============

WELCOME_MESSAGE = premium_emoji(
    "👋 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝘁𝗼 𝗦𝗵𝗮𝗱𝗼𝘄𝗫 𝗦𝗰𝗿𝗮𝗽𝗲𝗿 𝗕𝗼𝘁!\n\n"
    "💠 𝗬𝗼𝘂𝗿 𝗨𝗹𝘁𝗶𝗺𝗮𝘁𝗲 𝗖𝗿𝗲𝗱𝗶𝘁 𝗖𝗮𝗿𝗱 𝗦𝗰𝗿𝗮𝗽𝗶𝗻𝗴 𝗦𝗼𝗹𝘂𝘁𝗶𝗼𝗻\n\n"
    "📌 𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀:\n"
    "🔹 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗽𝘂𝗯𝗹𝗶𝗰/𝗽𝗿𝗶𝘃𝗮𝘁𝗲 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀\n"
    "🔹 𝗕𝗜𝗡 𝗳𝗶𝗹𝘁𝗲𝗿𝗶𝗻𝗴 𝘀𝘂𝗽𝗽𝗼𝗿𝘁\n"
    "🔹 𝗕𝗮𝗻𝗸 𝗻𝗮𝗺𝗲 𝗳𝗶𝗹𝘁𝗲𝗿𝗶𝗻𝗴\n"
    "🔹 𝗠𝘂𝗹𝘁𝗶-𝗰𝗵𝗮𝗻𝗻𝗲𝗹 𝘀𝗰𝗿𝗮𝗽𝗶𝗻𝗴\n"
    "🔹 𝗦𝗰𝗿𝗮𝗽𝗲 𝗮𝗹𝗹 𝗷𝗼𝗶𝗻𝗲𝗱 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀\n"
    "🔹 𝗔𝘂𝘁𝗼𝗺𝗮𝘁𝗶𝗰 𝗱𝘂𝗽𝗹𝗶𝗰𝗮𝘁𝗲 𝗿𝗲𝗺𝗼𝘃𝗮𝗹\n\n"
    "🚀 𝗥𝗲𝗮𝗱𝘆 𝘁𝗼 𝘀𝗰𝗿𝗮𝗽𝗲!"
)

START_MESSAGE = premium_emoji(
    "💠 𝗖𝗺𝗱 𝗦𝗵𝗮𝗱𝗼𝘄𝗫 𝗦𝗰𝗿𝗮𝗽𝗲𝗿\n\n"
    "📝 <code>/scr [channel] [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗮 𝘀𝗶𝗻𝗴𝗹𝗲 𝗰𝗵𝗮𝗻𝗻𝗲𝗹\n"
    "📝 <code>/mc [channel1] [channel2] [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗺𝘂𝗹𝘁𝗶𝗽𝗹𝗲 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀\n"
    "📝 <code>/scall [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗔𝗟𝗟 𝗷𝗼𝗶𝗻𝗲𝗱 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀 🚀\n\n"
    "📌 𝗘𝘅𝗮𝗺𝗽𝗹𝗲𝘀:\n"
    "🔹 <code>/scr @approved_card3 100</code>\n"
    "🔹 <code>/scr @approved_card3 100 515462</code>\n"
    "🔹 <code>/scr @approved_card3 100 BankName</code>\n"
    "🔹 <code>/scall 100</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗮𝗹𝗹 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀 🔥\n"
)

HELP_MESSAGE = premium_emoji(
    "📋 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 𝗟𝗶𝘀𝘁:\n\n"
    "🔹 <code>/scr [channel] [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗮 𝘀𝗶𝗻𝗴𝗹𝗲 𝗰𝗵𝗮𝗻𝗻𝗲𝗹\n"
    "🔹 <code>/mc [channel1] [channel2] [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗺𝘂𝗹𝘁𝗶𝗽𝗹𝗲 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀\n"
    "🔹 <code>/scall [limit]</code> - 𝗦𝗰𝗿𝗮𝗽𝗲 𝗳𝗿𝗼𝗺 𝗔𝗟𝗟 𝗷𝗼𝗶𝗻𝗲𝗱 𝗰𝗵𝗮𝗻𝗻𝗲𝗹𝘀 🚀\n"
    "🔹 <code>/start</code> - 𝗦𝗵𝗼𝘄 𝗺𝗮𝗶𝗻 𝗺𝗲𝗻𝘂\n\n"
    "☠️ <b>Bᴏᴛ Bʏ:</b> <a href='https://t.me/LUFFY_BR0'>𝗟𝗨𝗙𝗙𝗬</a>"
)

# ============ Core Functions ============

async def scrape_messages_with_progress(
    client: PyroClient,
    channel_id: Union[int, str],
    limit: int,
    channel_name: str,
    temp_msg: Message,
    current_channel: int,
    total_channels: int,
    overall_cards: int,
    start_time: float,
    start_number: Optional[str] = None,
    bank_name: Optional[str] = None
) -> Tuple[List[str], int]:
    """Scrape messages with progress tracking"""
    cards = []
    count = 0
    total_messages = 0
    last_update = time.time()
    update_interval = 2
    
    patterns = [
        r'\d{16}\D*\d{2}\D*\d{2,4}\D*\d{3,4}',
        r'\d{16}\s+\d{2}\s+\d{2,4}\s+\d{3,4}',
        r'\d{16}\|\d{2}\|\d{2,4}\|\d{3,4}',
        r'\d{16}\/\d{2}\/\d{2,4}\/\d{3,4}',
        r'\d{16}[\s\|/]\d{2}[\s\|/]\d{2,4}[\s\|/]\d{3,4}',
    ]
    
    logger.info(f"🔍 Scraping from: {channel_name} (limit: {limit})")
    
    try:
        async for message in client.search_messages(channel_id, limit=limit * 10):
            if count >= limit:
                break
            
            total_messages += 1
            text = message.text or message.caption
            if not text:
                continue
            
            if bank_name and bank_name.lower() not in text.lower():
                continue
            
            for pattern in patterns:
                matches = re.findall(pattern, text)
                if not matches:
                    continue
                
                for match in matches:
                    numbers = re.findall(r'\d+', match)
                    if len(numbers) == 4:
                        card_num, month, year, cvv = numbers
                        year = year[-2:]
                        
                        if not (15 <= len(card_num) <= 19):
                            continue
                        if not (1 <= int(month) <= 12):
                            continue
                        if not (3 <= len(cvv) <= 4):
                            continue
                        
                        if start_number:
                            if not card_num.startswith(start_number[:6]):
                                continue
                        
                        cards.append(f"{card_num}|{month}|{year}|{cvv}")
                        count += 1
                        
                        now = time.time()
                        if now - last_update >= update_interval:
                            last_update = now
                            await update_scrape_progress(
                                temp_msg, channel_name, current_channel, total_channels,
                                count, limit, overall_cards + count, len(cards),
                                start_time, total_messages
                            )
                        
                        if count >= limit:
                            break
                
                if count >= limit:
                    break
    
    except FloodWait as e:
        wait_time = e.value
        logger.warning(f"⏳ Flood wait {wait_time}s for {channel_name}")
        await asyncio.sleep(wait_time)
        return await scrape_messages_with_progress(
            client, channel_id, limit, channel_name, temp_msg,
            current_channel, total_channels, overall_cards, start_time,
            start_number, bank_name
        )
    
    except Exception as e:
        logger.error(f"❌ Error scraping {channel_name}: {e}")
    
    logger.info(f"✅ Scraped {len(cards)} cards from {channel_name}")
    return cards, total_messages

async def update_scrape_progress(
    temp_msg: Message,
    channel_name: str,
    current_channel: int,
    total_channels: int,
    current_cards: int,
    target_cards: int,
    overall_cards: int,
    total_found: int,
    start_time: float,
    messages_scanned: int
) -> None:
    """Update scrape progress with loading bar"""
    elapsed = time.time() - start_time
    elapsed_str = format_duration(elapsed)
    
    channel_percentage = min(100, (current_cards / target_cards) * 100) if target_cards > 0 else 0
    channel_bar = create_progress_bar(channel_percentage)
    
    overall_percentage = ((current_channel - 1) / total_channels) * 100 if total_channels > 0 else 0
    overall_bar = create_progress_bar(overall_percentage)
    
    speed = current_cards / elapsed if elapsed > 0 else 0
    
    if speed > 0:
        remaining_cards = (target_cards - current_cards) + sum([target_cards for _ in range(total_channels - current_channel)])
        remaining_time = remaining_cards / speed if speed > 0 else 0
        remaining_str = format_duration(remaining_time)
    else:
        remaining_str = "Calculating..."
    
    progress_text = premium_emoji(
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⏳ Scraping {current_channel}/{total_channels}\n"
        f"📁 {channel_name[:30]}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 Channel: {channel_bar} {channel_percentage:.0f}% ({current_cards}/{target_cards})\n"
        f"📊 Overall: {overall_bar} {overall_percentage:.0f}% ({current_channel-1}/{total_channels})\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💳 Total Cards: {overall_cards:,} ({current_cards} new)\n"
        f"⏱️ {elapsed_str} | 📈 {speed:.1f}/s | ⏳ {remaining_str} remaining"
    )
    
    try:
        await temp_msg.edit_text(progress_text, parse_mode=ParseMode.HTML)
    except Exception:
        pass

def remove_duplicates(cards: List[str]) -> Tuple[List[str], int]:
    """Remove duplicate cards and return unique list with count"""
    unique = list(dict.fromkeys(cards))
    duplicates = len(cards) - len(unique)
    logger.info(f"🗑️ Removed {duplicates} duplicates")
    return unique, duplicates

async def join_private_chat(client: PyroClient, invite_link: str) -> bool:
    """Join a private chat using invite link"""
    try:
        await client.join_chat(invite_link)
        logger.info(f"✅ Joined chat: {invite_link}")
        return True
    except UserAlreadyParticipant:
        logger.info(f"ℹ️ Already in chat: {invite_link}")
        return True
    except InviteRequestSent:
        logger.info(f"📩 Join request sent: {invite_link}")
        return False
    except (InviteHashExpired, InviteHashInvalid) as e:
        logger.error(f"❌ Failed to join {invite_link}: {e}")
        return False

async def get_chat_from_identifier(identifier: str, temp_msg: Message) -> Tuple[Optional[Chat], str]:
    """Get chat from various identifier formats"""
    chat = None
    channel_name = ""
    
    if identifier.lstrip("-").isdigit():
        chat_id = int(identifier)
        try:
            chat = await user.get_chat(chat_id)
            channel_name = chat.title
            return chat, channel_name
        except Exception:
            await temp_msg.edit_text(premium_emoji(f"❌ Cannot access channel ID: {chat_id}"))
            return None, ""
    
    if identifier.startswith("https://t.me/+") or identifier.startswith("t.me/+"):
        invite_link = identifier
        await temp_msg.edit_text(premium_emoji("⏳ Joining private channel..."))
        
        try:
            joined = await join_private_chat(user, invite_link)
            if joined:
                chat = await user.get_chat(invite_link)
                channel_name = chat.title
                return chat, channel_name
            else:
                await temp_msg.edit_text(premium_emoji("❌ Cannot join private channel"))
                return None, ""
        except Exception as e:
            await temp_msg.edit_text(premium_emoji(f"❌ Error: {str(e)[:50]}"))
            return None, ""
    
    if identifier.startswith("https://t.me/"):
        channel_username = identifier[13:]
    elif identifier.startswith("t.me/"):
        channel_username = identifier[5:]
    elif identifier.startswith("@"):
        channel_username = identifier[1:]
    else:
        channel_username = identifier
    
    try:
        chat = await user.get_chat(channel_username)
        channel_name = chat.title
        return chat, channel_name
    except Exception:
        if len(identifier) > 10 and not identifier.startswith("@"):
            invite_link = f"https://t.me/+{identifier}"
            joined = await join_private_chat(user, invite_link)
            if joined:
                chat = await user.get_chat(invite_link)
                channel_name = chat.title
                return chat, channel_name
        
        await temp_msg.edit_text(premium_emoji("❌ Invalid channel identifier"))
        return None, ""

async def send_results(
    message: Message,
    unique_cards: List[str],
    duplicates_removed: int,
    source_name: str,
    bin_filter: Optional[str] = None,
    bank_filter: Optional[str] = None,
    duration: float = 0.0,
    notify_admin: bool = True
) -> None:
    """Send scraping results as a file"""
    if not unique_cards:
        await message.edit_text(premium_emoji("❌ <b>No Credit Cards Found</b>"))
        return
    
    safe_source = sanitize_filename(source_name.replace(' ', '_'))
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{TEMP_DIR}/cards_{safe_source}_{timestamp}_{len(unique_cards)}.txt"
    
    try:
        async with aiofiles.open(file_name, mode='w', encoding='utf-8') as f:
            await f.write("\n".join(unique_cards))
    except Exception as e:
        logger.error(f"❌ Error writing file: {e}")
        await message.edit_text(premium_emoji("❌ <b>Error saving results</b>"))
        return
    
    user_link = await get_user_link(message.from_user)
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    caption = premium_emoji(
        f"💎 <b>LUFFY Scraped Results</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 User: {user_link}\n"
        f"📁 Source: <code>{source_name}</code>\n"
        f"💳 Total: <code>{len(unique_cards)}</code>\n"
        f"🗑️ Duplicates: <code>{duplicates_removed}</code>\n"
        f"⏱️ Time: <code>{duration:.2f}s</code>\n"
        f"📅 Date: <code>{current_time}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"☠️ <b>Bot By:</b> <a href='https://t.me/{BOT_OWNER}'>LUFFY</a>"
    )
    
    if bin_filter:
        caption = premium_emoji(f"🔍 <b>BIN Filter:</b> <code>{bin_filter}</code>\n") + caption
    if bank_filter:
        caption = premium_emoji(f"🏦 <b>Bank Filter:</b> <code>{bank_filter}</code>\n") + caption
    
    try:
        await message.delete()
    except:
        pass
    
    try:
        await bot.send_document(
            chat_id=message.chat.id,
            document=FSInputFile(file_name),
            caption=caption,
            parse_mode=ParseMode.HTML
        )
        logger.info(f"✅ Results sent: {len(unique_cards)} cards from {source_name}")
        
        if notify_admin:
            await notify_admins_about_scrape(message.from_user, len(unique_cards), source_name, duration)
            
    except Exception as e:
        logger.error(f"❌ Error sending document: {e}")
        await bot.send_message(
            chat_id=message.chat.id,
            text=premium_emoji(f"❌ <b>Error sending results:</b>\n<code>{str(e)}</code>"),
            parse_mode=ParseMode.HTML
        )
    finally:
        try:
            os.remove(file_name)
        except:
            pass

async def get_user_link(user: User) -> str:
    if user.username:
        return f'<a href="t.me/{user.username}">{user.first_name}</a>'
    return user.first_name or "User"

async def notify_admins_about_scrape(user: User, card_count: int, source: str, duration: float) -> None:
    """Notify all admins about a scrape"""
    user_link = await get_user_link(user)
    notification = premium_emoji(
        f"📢 <b>Scrape Notification</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 User: {user_link}\n"
        f"📁 Source: <code>{source}</code>\n"
        f"💳 Cards: <code>{card_count}</code>\n"
        f"⏱️ Time: <code>{duration:.2f}s</code>\n"
        f"📅 Time: <code>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"☠️ <b>LUFFY Scraper</b>"
    )
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, notification, parse_mode=ParseMode.HTML)
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")

# ============ Keyboards ============

def get_main_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📊 Sᴛᴀᴛs", callback_data="stats"),
            InlineKeyboardButton(text="📝 Cᴏᴍᴍᴀɴᴅs", callback_data="show_cmd")
        ],
        [
            InlineKeyboardButton(text="👤 Oᴡɴᴇʀ", url=f"https://t.me/{BOT_OWNER}"),
            InlineKeyboardButton(text="📢 Cʜᴀɴɴᴇʟ", url=f"https://t.me/{BOT_CHANNEL}")
        ],
        [
            InlineKeyboardButton(text="❓ Hᴇʟᴘ", callback_data="help_menu")
        ]
    ])

def get_back_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Bᴀᴄᴋ", callback_data="back_to_menu")]
    ])

def get_stats_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Rᴇғʀᴇsʜ", callback_data="stats")],
        [InlineKeyboardButton(text="🔙 Bᴀᴄᴋ", callback_data="back_to_menu")]
    ])

def get_help_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 Cᴏᴍᴍᴀɴᴅ Lɪsᴛ", callback_data="show_cmd")],
        [InlineKeyboardButton(text="🔙 Bᴀᴄᴋ", callback_data="back_to_menu")]
    ])

# ============ Bot Commands ============

@dp.message(Command("start"))
async def start_command(message: Message):
    try:
        photo = FSInputFile("cc.jpg")
        await bot.send_photo(
            chat_id=message.chat.id,
            photo=photo,
            caption=WELCOME_MESSAGE,
            reply_markup=get_main_menu_keyboard()
        )
    except FileNotFoundError:
        await message.reply(WELCOME_MESSAGE, reply_markup=get_main_menu_keyboard(), parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"Error in start: {e}")
        await message.reply(WELCOME_MESSAGE, reply_markup=get_main_menu_keyboard(), parse_mode=ParseMode.HTML)

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.reply(HELP_MESSAGE, parse_mode=ParseMode.HTML, reply_markup=get_help_keyboard())

@dp.callback_query(F.data == "help_menu")
async def help_menu_callback(callback: CallbackQuery):
    await callback.answer()
    try:
        await callback.message.edit_caption(
            caption=HELP_MESSAGE,
            reply_markup=get_help_keyboard(),
            parse_mode=ParseMode.HTML
        )
    except:
        await callback.message.edit_text(
            HELP_MESSAGE,
            reply_markup=get_help_keyboard(),
            parse_mode=ParseMode.HTML
        )

@dp.callback_query(F.data == "show_cmd")
async def show_cmd_callback(callback: CallbackQuery):
    try:
        await callback.message.edit_caption(caption=START_MESSAGE, reply_markup=get_back_keyboard(), parse_mode=ParseMode.HTML)
    except:
        try:
            await callback.message.edit_text(START_MESSAGE, reply_markup=get_back_keyboard(), parse_mode=ParseMode.HTML)
        except:
            pass
    await callback.answer()

@dp.callback_query(F.data == "back_to_menu")
async def back_to_menu_callback(callback: CallbackQuery):
    try:
        await callback.message.edit_caption(caption=WELCOME_MESSAGE, reply_markup=get_main_menu_keyboard(), parse_mode=ParseMode.HTML)
    except:
        try:
            await callback.message.edit_text(WELCOME_MESSAGE, reply_markup=get_main_menu_keyboard(), parse_mode=ParseMode.HTML)
        except:
            pass
    await callback.answer()

@dp.callback_query(F.data == "stats")
async def stats_callback(callback: CallbackQuery):
    await callback.answer()
    try:
        me = await bot.get_me()
        channels_count = len(user_manager.get_user_channels(callback.from_user.id))
        
        stats = premium_emoji(
            f"📊 <b>Bot Statistics</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🤖 Bot: <code>{me.first_name}</code>\n"
            f"🆔 ID: <code>{me.id}</code>\n"
            f"👤 Admins: <code>{len(ADMIN_IDS)}</code>\n"
            f"📊 Default Limit: <code>{DEFAULT_LIMIT}</code>\n"
            f"⭐ Admin Limit: <code>{ADMIN_LIMIT}</code>\n"
            f"📁 Your Channels: <code>{channels_count}</code>\n"
            f"💻 Workers: <code>{WORKERS}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"☠️ <b>By:</b> <a href='https://t.me/{BOT_OWNER}'>LUFFY</a>"
        )
        await callback.message.delete()
        await callback.message.answer(stats, reply_markup=get_stats_keyboard(), parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"Stats error: {e}")

# ============ Scrape Commands ============

@dp.message(Command("scr"))
async def scr_command(message: Message, command: CommandObject):
    """Scrape from single channel"""
    args = command.args.split() if command.args else []
    
    if len(args) < 2:
        await message.reply(premium_emoji("⚠️ Provide channel username and amount to scrape ❌"))
        return
    
    channel_identifier = args[0]
    try:
        limit = int(args[1])
    except ValueError:
        await message.reply(premium_emoji("⚠️ Invalid limit value. provide a valid number"))
        return
    
    user_id = message.from_user.id
    max_lim = ADMIN_LIMIT if user_id in ADMIN_IDS else DEFAULT_LIMIT
    
    if limit > max_lim:
        await message.reply(premium_emoji(f"⚠️ Amount over Max limit is {max_lim} "))
        return
    
    start_number = None
    bank_name = None
    bin_filter = None
    
    if len(args) > 2:
        if args[2].isdigit():
            start_number = args[2]
            bin_filter = args[2][:6]
        else:
            bank_name = " ".join(args[2:])
    
    temp_msg = await message.reply(premium_emoji("⏳ Checking the username..."))
    await asyncio.sleep(1.5)
    
    chat = None
    channel_name = ""
    
    try:
        chat, channel_name = await get_chat_from_identifier(channel_identifier, temp_msg)
        if not chat:
            return
    except Exception as e:
        await temp_msg.edit_text(premium_emoji("❌ Incorrect username or chat ID "))
        return
    
    await temp_msg.edit_text(premium_emoji("⏳ Scraping In Progress..."))
    start_time = time.time()
    
    scrapped_results = await scrape_messages_with_progress(
        user, chat.id, limit, channel_name, temp_msg,
        1, 1, 0, start_time, start_number, bank_name
    )
    
    cards, messages_scanned = scrapped_results
    unique_messages, duplicates_removed = remove_duplicates(cards)
    duration = time.time() - start_time
    
    await send_results(temp_msg, unique_messages, duplicates_removed, channel_name, bin_filter, bank_name, duration)

@dp.message(Command("mc"))
async def mc_command(message: Message, command: CommandObject):
    """Scrape from multiple channels"""
    args = command.args.split() if command.args else []
    
    if len(args) < 2:
        await message.reply(premium_emoji("⚠️ Provide at least one channel username"))
        return
    
    channel_identifiers = args[:-1]
    try:
        limit = int(args[-1])
    except ValueError:
        await message.reply(premium_emoji("⚠️ Invalid limit value. provide a valid number"))
        return
    
    user_id = message.from_user.id
    max_lim = ADMIN_LIMIT if user_id in ADMIN_IDS else DEFAULT_LIMIT
    
    if limit > max_lim:
        await message.reply(premium_emoji(f"⚠️ Amount over Max limit is {max_lim} "))
        return
    
    temp_msg = await message.reply(premium_emoji("⏳ Scraping In Progress..."))
    all_messages = []
    channel_names = []
    total_channels = len(channel_identifiers)
    overall_cards = 0
    start_time = time.time()
    
    for idx, identifier in enumerate(channel_identifiers, 1):
        try:
            chat, name = await get_chat_from_identifier(identifier, temp_msg)
            if not chat:
                continue
            
            channel_names.append(name)
            
            results, scanned = await scrape_messages_with_progress(
                user, chat.id, limit, name, temp_msg,
                idx, total_channels, overall_cards, start_time
            )
            
            all_messages.extend(results)
            overall_cards += len(results)
            logger.info(f"✅ Scraped {len(results)} from {name}")
            
        except Exception as e:
            logger.error(f"❌ Error scraping {identifier}: {e}")
            continue
    
    unique_messages, duplicates_removed = remove_duplicates(all_messages)
    unique_messages = unique_messages[:limit]
    duration = time.time() - start_time
    
    if not unique_messages:
        await temp_msg.edit_text(premium_emoji("❌ No Cards Found"))
    else:
        source_name = f"Multiple ({len(channel_names)} channels)"
        await send_results(temp_msg, unique_messages, duplicates_removed, source_name, duration=duration)

@dp.message(Command("scall"))
async def scall_command(message: Message, command: CommandObject):
    """Scrape from all joined channels - ADMIN ONLY"""
    user_id = message.from_user.id
    
    if user_id not in ADMIN_IDS:
        await message.reply(premium_emoji("❌ <b>Admin Only Command</b>\n\nThis command is restricted to bot admins."))
        return
    
    args = command.args.split() if command.args else []
    
    if len(args) < 1:
        await message.reply(premium_emoji("⚠️ Provide the limit to scrape ❌\n📌 Example: <code>/scall 100</code>"))
        return
    
    try:
        limit = int(args[0])
    except ValueError:
        await message.reply(premium_emoji("⚠️ Invalid limit value. provide a valid number"))
        return
    
    if limit > ADMIN_LIMIT:
        await message.reply(premium_emoji(f"⚠️ Amount over Max limit is {ADMIN_LIMIT} "))
        return
    
    temp_msg = await message.reply(premium_emoji("⏳ Getting all joined channels..."))
    
    channels = await get_all_joined_channels(user)
    
    if not channels:
        await temp_msg.edit_text(premium_emoji("❌ No channels found! Make sure you are joined to some channels."))
        return
    
    await temp_msg.edit_text(
        premium_emoji(f"📊 Found <b>{len(channels)}</b> channels\n⏳ Starting scrape...")
    )
    
    all_messages = []
    total_channels = len(channels)
    overall_cards = 0
    start_time = time.time()
    
    for idx, channel in enumerate(channels, 1):
        channel_id = channel["id"]
        channel_title = channel["title"]
        
        try:
            results, scanned = await scrape_messages_with_progress(
                user, channel_id, limit, channel_title, temp_msg,
                idx, total_channels, overall_cards, start_time
            )
            
            all_messages.extend(results)
            overall_cards += len(results)
            logger.info(f"✅ Scraped {len(results)} from {channel_title}")
            
        except Exception as e:
            logger.error(f"❌ Error scraping {channel_title}: {e}")
            continue
    
    unique_messages, duplicates_removed = remove_duplicates(all_messages)
    unique_messages = unique_messages[:limit]
    duration = time.time() - start_time
    
    if not unique_messages:
        await temp_msg.edit_text(premium_emoji(f"❌ No Cards Found\n\n📁 Scanned: {len(channels)} channels"))
    else:
        source_name = f"All Channels ({len(channels)})"
        await send_results(temp_msg, unique_messages, duplicates_removed, source_name, duration=duration)

async def send_join_request(client, invite_link):
    try:
        await client.join_chat(invite_link)
        logger.info(f"Sent join request to chat: {invite_link}")
        return True
    except PeerIdInvalid as e:
        logger.error(f"Failed to send join request to chat {invite_link}: {e}")
        return False
    except InviteRequestSent:
        logger.info(f"Join request sent to the chat: {invite_link}")
        return False

async def get_all_joined_channels(client: PyroClient) -> List[Dict[str, Any]]:
    """Get all channels the user has joined"""
    channels = []
    try:
        async for dialog in client.get_dialogs():
            chat = dialog.chat
            if chat.type in [ChatType.CHANNEL, ChatType.SUPERGROUP]:
                try:
                    member = await client.get_chat_member(chat.id, "me")
                    if member.status in [ChatMemberStatus.MEMBER, 
                                        ChatMemberStatus.ADMINISTRATOR, 
                                        ChatMemberStatus.OWNER]:
                        channels.append({
                            "id": chat.id,
                            "title": chat.title,
                            "username": chat.username or "Private",
                            "type": "channel" if chat.type == ChatType.CHANNEL else "group"
                        })
                except Exception as e:
                    logger.warning(f"⚠️ Could not check membership for {chat.title}: {e}")
    except Exception as e:
        logger.error(f"❌ Error getting dialogs: {e}")
    
    return channels

# ============ Error Handler ============

@dp.errors()
async def error_handler(update, exception):
    """Global error handler"""
    logger.error(f"Error: {exception}")
    
    if isinstance(exception, TelegramBadRequest):
        if "message to edit not found" in str(exception) or "message to reply not found" in str(exception):
            return True
    
    return False

# ============ Main ============

async def main():
    try:
        logger.info("=" * 50)
        logger.info("🚀 LUFFY Scraper Bot Starting...")
        logger.info("=" * 50)
        
        # Validate Bot Token
        try:
            me = await bot.get_me()
            logger.info(f"✅ Bot authenticated: {me.first_name} (@{me.username})")
            logger.info(f"🆔 Bot ID: {me.id}")
        except Exception as e:
            logger.error(f"❌ Bot authentication failed: {e}")
            logger.error("⚠️ Please check BOT_TOKEN in config.py")
            return
        
        logger.info("Starting Pyrogram client...")
        await user.start()
        logger.info("✅ Pyrogram client started successfully")
        
        pyro_me = await user.get_me()
        logger.info(f"👤 Logged in as: {pyro_me.first_name} (@{pyro_me.username})")
        
        logger.info("🚀 Starting Aiogram bot polling...")
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(
            bot,
            allowed_updates=["message", "callback_query"],
            skip_updates=True
        )
        
    except KeyboardInterrupt:
        logger.info("🛑 Bot stopped by user")
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            await user.stop()
        except:
            pass
        try:
            await bot.session.close()
        except:
            pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("🛑 Bot stopped")
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()